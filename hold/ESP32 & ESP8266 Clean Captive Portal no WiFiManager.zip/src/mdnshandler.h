#ifndef _MDNSHANDLER_H
#define _MDNSHANDLER_H

#ifdef ESP32
#include <ESPmDNS.h>
#include <WiFi.h>
#elif ESP8266
#include <ESP8266mDNS.h>
#include <ESP8266WiFi.h>
#else
#error Platform not supported
#endif

#include <ArduinoLog.h>
#include <Arduino.h>

void mdnssetup();
void mdnsloop();

#endif // _MDNSHANDLER_H
