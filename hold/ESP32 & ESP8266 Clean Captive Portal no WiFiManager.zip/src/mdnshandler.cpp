#include "mdnshandler.h"

#define HTTPPORT 80

void mdnssetup()
{
    if (!MDNS.begin(WiFi.getHostname()))
    {
        Log.error(F("Error setting up mDNS responder." CR));
    }
    else
    {
        if (!MDNS.addService(WiFi.getHostname(), "tcp", HTTPPORT))
        {
            Log.error(F("Failed to register %s mDNS service." CR), WiFi.getHostname());
        }
        else
        {
            Log.notice(F("Host %s registered via mDNS on port %i." CR), WiFi.getHostname(), HTTPPORT);
        }
        if (!MDNS.addService("http", "tcp", HTTPPORT))
        {
            Log.error(F("Failed to register Web mDNS service." CR));
        }
        else
        {
            Log.notice(F("Web server registered via mDNS on port %i." CR), HTTPPORT);
        }
        Log.notice(F("mDNS responder started for %s.local." CR), WiFi.getHostname());
    }
}

void mdnsloop()
{
#ifdef ESP8266
    MDNS.update();
#endif
}
