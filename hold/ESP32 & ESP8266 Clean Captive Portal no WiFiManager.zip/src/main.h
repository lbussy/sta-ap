#ifndef _MAIN_H
#define _MAIN_H

#ifdef ESP32
#include <WiFi.h>
#elif ESP8266
#include <ESP8266WiFi.h>
#else
#error Platform not supported
#endif
#include <DNSServer.h>

#include <ArduinoLog.h>
#include <Arduino.h>

#include "webhandler.h"
#include "mdnshandler.h"

#endif // _MAIN_H
