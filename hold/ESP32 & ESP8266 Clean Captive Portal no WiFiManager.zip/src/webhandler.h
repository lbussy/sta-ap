#ifndef _CAPTIVE_H
#define _CAPTIVE_H

#ifdef ESP32
#include <WiFi.h>
#include <AsyncTCP.h>
#include <SPIFFS.h>
#elif ESP8266
#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>
#include <LittleFS.h>
#endif

#include <ESPAsyncWebServer.h>
#include <ArduinoLog.h>
#include <Arduino.h>

void initWebServer();
void handlePages(AsyncWebServerRequest *request, bool isCaptive = false);

#endif // _CAPTIVE_H
