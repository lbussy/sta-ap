#include "main.h"
#include "../../secret.h"

#define HOSTNAME "esp-captive"

DNSServer dnsServer;

void setup()
{
    Serial.begin(BAUD);
    Serial.flush();
    Serial.println("\n");
    Log.begin(LOG_LEVEL_VERBOSE, &Serial, true);
    Log.notice(F("Beginning sketch." CR));

    WiFi.disconnect();
    Log.notice(F("Connecting to %s."), SSID);
    WiFi.mode(WIFI_AP_STA);
    WiFi.begin(SSID, PSWD);
    WiFi.setHostname(HOSTNAME);
    while (WiFi.status() != WL_CONNECTED)
    {
        delay(500);
        Serial.print(".");
    }
    Serial.println();
    Log.notice(F("Connected to %s as %s, IP address %p." CR), SSID, WiFi.getHostname(), WiFi.localIP());

    WiFi.softAP(HOSTNAME);
    dnsServer.start(53, "*", WiFi.softAPIP());

    mdnssetup();

    initWebServer();
}

void loop()
{
    dnsServer.processNextRequest();
    mdnsloop();
}
